/** Automatically generated file. DO NOT MODIFY */
package com.example.flames;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}