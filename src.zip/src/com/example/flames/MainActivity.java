package com.example.flames;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import java.io.*;

//import com.example.crap.DisplayMessageActivity;
//import com.example.crap.R;

//import com.example.calc.R;
public class MainActivity extends Activity {

	String op;
	
	EditText num1 ;
	
	EditText num2 ;
	EditText res ;
	 public final static String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	
num1 = (EditText)findViewById(R.id.editText2); 

num2 = (EditText)findViewById(R.id.editText1); 



	}

public void addiH(View vi)
{
	
   //  int x = Integer.parseInt(num1.getText().toString());		
	
	String first = num1.getText().toString();
	
    // int y = Integer.parseInt(num2.getText().toString());		
		
	String second = num2.getText().toString();
	
    //int op =x+y;
	
	StringBuffer s1=new StringBuffer(first);
	StringBuffer s2=new StringBuffer(second);
	int a=s1.length();
	int b=s2.length();

    //comparing two names
	label: for(int i=0;i<a;i++)
	{
		char c=s1.charAt(i);
	//	System.out.println(c);
		for(int j=0;j<b;j++)
		{
			char d=s2.charAt(j);
			if(c==d)
			{
				 ////k++;
				 s1.deleteCharAt(i);
				 s2.deleteCharAt(j);
				 ////System.out.println(s1 +" " +s2);
				 a=s1.length();
				 //m=a;
				 b=s2.length();
				 i=0;
				 j=0;
				// continue label;
			}
					}

////	System.out.println(k);
	}
  int d=(a+b);
  //System.out.println("the number is : " +d);
  //int n=-1,l=0,p=0;
  StringBuffer s3=new StringBuffer("flames");
  String s4=new String();

label1:	for(int i=0;i<5;i++)
	{
		int n=-1,l=0,p=0;
		for(int j=1;j<=d;j++)
		{
		n++;
		l++;
		//int p=0;
		if(n>s3.length()-1)
			{
			
			if(l==d)
				{
				s3.deleteCharAt(p);
				//String s4=new String();
				s4=s3.substring(p,s3.length());
				////System.out.println(s4);
				s3.delete(p,s3.length());
				////System.out.println(s3);
				s3.insert(0,s4);
				////System.out.println(s3);
				break;
				}
				else{ p++;
				     if(p==s3.length())
				     {p=0;
				     }
                    }
			}
		else
			{
			
			if(l==d)
				{
				s3.deleteCharAt(n);

				s4=s3.substring(n,s3.length());
				////System.out.println(s4);
				s3.delete(n,s3.length());
		    	////System.out.println(s3);
				s3.insert(0,s4);
				////System.out.println(s3);
		    	break;
				}
				//break;
    		}

		}
		 }
////System.out.println(s3);
char result=s3.charAt(0);
switch(result){
	case 'f':
	     //System.out.println(second+" is ur Friend");
	    
                
	op =  "is ur Friend";

	
	
	
	
	Intent intent = new Intent(this, SubActivity1.class);
	//EditText editText = (EditText) findViewById(R.id.edit_message);
	//String message = editText.getText().toString();
String message = op;

	intent.putExtra(EXTRA_MESSAGE ,message);
	startActivity(intent);
	
	
	
	
	
	
	
	
	
	
	 break;
	case 'l':
		// System.out.println(second+" is ur Love");

		op = "is ur Love";	

		
		
		
		Intent inten = new Intent(this, SainActivity6.class);
		//EditText editText = (EditText) findViewById(R.id.edit_message);
		//String message = editText.getText().toString();
		String messag = op;

		inten.putExtra(EXTRA_MESSAGE, messag);
		startActivity(inten);
		
		
	
		
		
		
		
		
		 break;
    case 'a':
    	// System.out.println(second+" is ur Affection");
    	 
		
	op = " is ur Affection";


	
	

	Intent inte = new Intent(this, SubActivity3.class);
	//EditText editText = (EditText) findViewById(R.id.edit_message);
	//String message = editText.getText().toString();
	String messa = op;

	inte.putExtra(EXTRA_MESSAGE, messa);
	startActivity(inte);
	
	
	
	
	
	
	

			break;
    case 'm':
    	// System.out.println("u r going to marry "+ second);
    	
		op =  "u r going to marry ";

		
		
	Intent intg = new Intent(this, SainActivity4.class);
		//EditText editText = (EditText) findViewById(R.id.edit_message);
		//String message = editText.getText().toString();
		String mess = op;

		intg.putExtra(EXTRA_MESSAGE, mess);
		startActivity(intg);
		
		
	
		
			 break;
    case 'e':
    	// System.out.println(second + " is ur Enemy");
				
		op = " is ur Enemy";

		
		
		Intent inti = new Intent(this, SainActivity5.class);
		//EditText editText = (EditText) findViewById(R.id.edit_message);
		//String message = editText.getText().toString();
		String mes = op;

		inti.putExtra(EXTRA_MESSAGE, mes);
		startActivity(inti);
		
		
		
		
		
		
		

    	 break;
    case 's':
    	// System.out.println(second +" is ur Sister");
    	 
				op =	" is ur Sister";	
        
				Intent into = new Intent(this, SubActivity6.class);
				//EditText editText = (EditText) findViewById(R.id.edit_message);
				//String message = editText.getText().toString();
				String me = op;

				into.putExtra(EXTRA_MESSAGE, me);
				startActivity(into);
				
				
		
		
				
				
		
		
		
		
		
		break;
		      }
	





/*Intent intent = new Intent(this, SubActivity1.class);
//EditText editText = (EditText) findViewById(R.id.edit_message);
//String message = editText.getText().toString();
String message = op;

intent.putExtra(EXTRA_MESSAGE, message);
startActivity(intent);


*/




















































/*	
	res.setText(op);  */
	//result.setText(Integer.toString(op));
	}




/*public void subt(View v){
	
	
     int x = Integer.parseInt(num1.getText().toString());		
		
     int y = Integer.parseInt(num2.getText().toString());		
		
     int op =x-y;
	
	result.setText(Integer.toString(op));
	}


public void multi(View vie)
	
{
	
     int x = Integer.parseInt(num1.getText().toString());		
		
     int y = Integer.parseInt(num2.getText().toString());		
		
     int op =x*y;
	
	result.setText(Integer.toString(op));


}

public void divi(View view)
{
     int x = Integer.parseInt(num1.getText().toString());		
		
     int y = Integer.parseInt(num2.getText().toString());		
		
     int op =x/y;
	
	result.setText(Integer.toString(op));
	
}*/
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
